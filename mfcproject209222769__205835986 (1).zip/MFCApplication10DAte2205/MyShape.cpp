#include "pch.h"
#include "MyShape.h"

IMPLEMENT_SERIAL(MyShape, CObject, 1)
IMPLEMENT_SERIAL(MyCircle, CObject, 1)
IMPLEMENT_SERIAL(MyPolygon, CObject, 1)
IMPLEMENT_SERIAL(MySquare, CObject, 1)
IMPLEMENT_SERIAL(MyTriangle, CObject, 1)
