#pragma once
#include "pch.h"
// MyRectangle , MyCircle , MyEllipse

class MyShape : public CObject {
	DECLARE_SERIAL(MyShape)

public:
	int x0, y0, x1, y1;
public:

	MyShape() {}
	MyShape(const int& x0, const int& y0, const int& x1, const int& y1) : // RGB(102, 178,255)
		x0(x0), y0(y0), x1(x1), y1(y1) {} //  (192,192,192)

	int getX1() const { return x0; }
	int getX2() const { return x1; }
	int getY1() const { return y0; }
	int getY2() const { return y1; }


	virtual void Draw(CDC& dc) {}
	virtual ~MyShape() {}

public:
	void Serialize(CArchive& ar)
	{
		CObject::Serialize(ar);
		if (ar.IsStoring()) // SAVE
		{
			ar << x0;
			ar << x1;
			ar << y0;
			ar << y1;

		}
		else // Loading, not storing
		{
			ar >> x0;
			ar >> x1;
			ar >> y0;
			ar >> y1;

		}
	}
};

class MyCircle :public MyShape {
	DECLARE_SERIAL(MyCircle)
public:
	MyCircle() {}
	MyCircle(const int& x0, const int& y0, const int& x1, const int& y1) :
		MyShape(x0, y0, x1, y1) {}

	void Draw(CDC& dc) {
		CBrush myBrush, * oldBrush;
		CPen myPen(PS_SOLID, 2, RGB(102, 178, 255)), * oldPen;
		oldPen = dc.SelectObject(&myPen);
		dc.SetROP2(R2_NOTXORPEN);
		myBrush.CreateSolidBrush(RGB(150, 150, 150));
		oldBrush = dc.SelectObject(&myBrush);
		dc.Ellipse(x0, y0, x1, y1);
		dc.SelectObject(oldBrush);
		dc.SelectObject(oldPen);
		dc.SetROP2(R2_COPYPEN);
	}
};

class MyPolygon : public MyShape {
	DECLARE_SERIAL(MyPolygon)
protected:
	COLORREF polyColor;

public:
	MyPolygon() {}
	~MyPolygon() {}
	MyPolygon(const int& x0, const int& y0, const int& x1, const int& y1, const COLORREF& color = RGB(100, 149, 237)) :
		MyShape(x0, y0, x1, y1), polyColor(color) {}

	void setPolyColor(const COLORREF& color) { polyColor = color; }
	COLORREF getPolyColor() { return polyColor; }

	virtual bool isInPoly(const int& a0, const int& b0) { return false; }

	void Serialize(CArchive& ar) {
		MyShape::Serialize(ar);
		if (ar.IsStoring())
			ar << polyColor;
		else
			ar >> polyColor;

	}

};

class MySquare :public MyPolygon {
	DECLARE_SERIAL(MySquare)
public:
	MySquare() {}
	MySquare(const int& x0, const int& y0, const int& x1, const int& y1, const COLORREF& color) :
		MyPolygon(x0, y0, x1, y1, color) {}

	bool isInPoly(const int& a0, const int& b0) {
		if ((x0 <= a0 && a0 >= x1) && (y0 <= b0 >= y1)) return true;
		return false;
	}

	bool isEx(CPoint p) {

		int a0 = p.x, b0 = p.y;
		if ((x0 <= a0 && a0 <= x1) && (y0 <= b0 && b0 <= y1)) return true;
		return false;

	}


	void Draw(CDC& dc) {
		CBrush myBrush, * oldBrush;
		CPen myPen(PS_SOLID, 0, polyColor), * oldPen;
		oldPen = dc.SelectObject(&myPen);
		dc.SetROP2(R2_NOTXORPEN);
		myBrush.CreateSolidBrush(polyColor);
		oldBrush = dc.SelectObject(&myBrush);
		dc.Rectangle(x0, y0, x1, y1);
		dc.SelectObject(oldBrush);
		dc.SelectObject(oldPen);
		dc.SetROP2(R2_COPYPEN);
	}
};


// RGB(0, 0, 128) navy color +- (65,105,225) royal ;


class  MyTriangle : public MyPolygon {
	DECLARE_SERIAL(MyTriangle)
public:
	MyTriangle() {}


	MyTriangle(const int& x0, const int& y0, const int& x1, const int& y1, const COLORREF& color)
		:MyPolygon(x0, y0, x1, y1, color) {}

	void Draw(CDC& dc) {
		CPoint pt[3];
		pt[0].SetPoint(x0, y1);
		pt[1].SetPoint(x1, y1);
		pt[2].SetPoint((x0 + x1) / 2, y0);

		CBrush myBrush, * oldBrush;
		CPen myPen(PS_SOLID, 0, polyColor), * oldPen;
		oldPen = dc.SelectObject(&myPen);
		dc.SetROP2(R2_NOTXORPEN);
		myBrush.CreateSolidBrush(polyColor);
		oldBrush = dc.SelectObject(&myBrush);
		dc.SelectObject(myBrush);
		dc.Polygon(pt, 3);
		dc.SelectObject(oldBrush);
		dc.SelectObject(oldPen);
		dc.SetROP2(R2_COPYPEN);
	}

	/*
	bool isEx(CPoint p) {

		int minX = x0 < x1 ? x0 : x1  , maxX = x0 > x1 ? x0 : x1, minY = y0 < y1 ? x0 : x1, maxY = y0 > y1 ? y0 : y1;
	if (!(p.x < minX || p.x > maxX || p.y < minY || p.y > maxY))
	return 1;
	return 0;
	}
	*/

};
