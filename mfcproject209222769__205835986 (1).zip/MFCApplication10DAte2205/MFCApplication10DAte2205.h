
// MFCApplication10DAte2205.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'pch.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CMFCApplication10DAte2205App:
// See MFCApplication10DAte2205.cpp for the implementation of this class
//

class CMFCApplication10DAte2205App : public CWinApp
{
public:
	CMFCApplication10DAte2205App();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CMFCApplication10DAte2205App theApp;
