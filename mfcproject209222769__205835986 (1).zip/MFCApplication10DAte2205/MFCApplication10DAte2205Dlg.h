
// MFCApplication10DAte2205Dlg.h : header file
//

#pragma once

#include "MyShape.h"
#include "GameLogic.h"


// CMFCApplication10DAte2205Dlg dialog
class CMFCApplication10DAte2205Dlg : public CDialogEx
{
// Construction
public:
	CMFCApplication10DAte2205Dlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MFCAPPLICATION10DATE2205_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	CMFCColorButton m_Color;

	COLORREF myColor;


private:

	void initGame();


	int startX = 300, startY = 200, end = 600;
	void DrawShapes();


	CTypedPtrArray <CObArray, MyShape*> myShapes;

	bool IsInTheSquare(int indexX, int indexY, int x, int y);

	bool IndexesOfNewShape(int *ptrIndexX, int *ptrIndexY , CPoint point);

	GameLogic game;

	void UpdateScore(int player1Score, int player2Score);

	int scorePlayer1 = 0;
	int scorePlayer2 = 0;

	bool gameActive = true;

	void DeleteMyShape();

public:
	afx_msg void OnBnClickedbtnrematch();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnBnClickedMfccolorbutton1();
	afx_msg void OnBnClickedbtnsave();
	afx_msg void OnBnClickedbtnload();
	afx_msg void OnBnClickedbtnbyebye();
};
