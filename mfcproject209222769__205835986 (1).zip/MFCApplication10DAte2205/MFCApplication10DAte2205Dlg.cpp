
// MFCApplication10DAte2205Dlg.cpp : implementation file
//

#include "pch.h"
#include "framework.h"
#include "MFCApplication10DAte2205.h"
#include "MFCApplication10DAte2205Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CMFCApplication10DAte2205Dlg dialog



CMFCApplication10DAte2205Dlg::CMFCApplication10DAte2205Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_MFCAPPLICATION10DATE2205_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCApplication10DAte2205Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_MFCCOLORBUTTON1, m_Color);

}

BEGIN_MESSAGE_MAP(CMFCApplication10DAte2205Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_LBUTTONDOWN()
	ON_BN_CLICKED(btnRematch, &CMFCApplication10DAte2205Dlg::OnBnClickedbtnrematch)
	ON_WM_RBUTTONDOWN()
	ON_BN_CLICKED(IDC_MFCCOLORBUTTON1, &CMFCApplication10DAte2205Dlg::OnBnClickedMfccolorbutton1)
	ON_BN_CLICKED(btnSave, &CMFCApplication10DAte2205Dlg::OnBnClickedbtnsave)
	ON_BN_CLICKED(btnLoad, &CMFCApplication10DAte2205Dlg::OnBnClickedbtnload)
	ON_BN_CLICKED(btnByebye, &CMFCApplication10DAte2205Dlg::OnBnClickedbtnbyebye)
END_MESSAGE_MAP()


// CMFCApplication10DAte2205Dlg message handlers

BOOL CMFCApplication10DAte2205Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	initGame();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMFCApplication10DAte2205Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMFCApplication10DAte2205Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		initGame();
		// DrawShapes();
		CDialogEx::OnPaint();
	}

}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMFCApplication10DAte2205Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


bool CMFCApplication10DAte2205Dlg::IsInTheSquare(int indexX, int indexY, int x, int y)
{

	return (startX + 200 * indexX <= x && x <= startX + 200 * (indexX + 1)) && (startY + 200 * indexY <= y && y <= startY + 200 * (indexY + 1));

}

bool CMFCApplication10DAte2205Dlg::IndexesOfNewShape(int* ptrIndexX, int* ptrIndexY, CPoint point)
{
	bool answer = true;

	int indexX = -1;
	int indexY = -1;

	if (IsInTheSquare(0, 0, point.x, point.y))
	{
		indexX = 0, indexY = 0;
	}
	else if (IsInTheSquare(0, 1, point.x, point.y))
	{
		indexX = 0, indexY = 1;
	}
	else if (IsInTheSquare(0, 2, point.x, point.y))
	{
		indexX = 0, indexY = 2;
	}
	else if (IsInTheSquare(1, 0, point.x, point.y))
	{
		indexX = 1, indexY = 0;
	}
	else if (IsInTheSquare(1, 1, point.x, point.y))
	{
		indexX = 1, indexY = 1;
	}
	else if (IsInTheSquare(1, 2, point.x, point.y))
	{
		indexX = 1, indexY = 2;
	}
	else if (IsInTheSquare(2, 0, point.x, point.y))
	{
		indexX = 2, indexY = 0;
	}
	else if (IsInTheSquare(2, 1, point.x, point.y))
	{
		indexX = 2, indexY = 1;
	}
	else if (IsInTheSquare(2, 2, point.x, point.y))
	{
		indexX = 2, indexY = 2;
	}
	else
	{
		answer = false;
	}

	*ptrIndexX = indexX;
	*ptrIndexY = indexY;

	return answer;
}

void CMFCApplication10DAte2205Dlg::UpdateScore(int player1Score, int player2Score)
{
	CStatic* labelPlayer1 = (CStatic*)GetDlgItem(labelPlayer1Points);
	CStatic* labelPlayer2 = (CStatic*)GetDlgItem(labelPlayer2Points);

	CString strP1;
	CString strP2;

	strP1.AppendFormat(_T("%d"), player1Score);
	strP2.AppendFormat(_T("%d"), player2Score);

	game.SetPlayer1Wins(scorePlayer1);
	game.SetPlayer2Wins(scorePlayer2);

	labelPlayer1->SetWindowTextW(strP1);
	labelPlayer2->SetWindowTextW(strP2);
}


void CMFCApplication10DAte2205Dlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default

	CString str;

	// str.AppendFormat(point.x);

	CString strPoint;
	strPoint.Format(_T(" (X: %d , Y:  %d "), point.x, point.y);

	// MessageBox(strPoint);

	int lengthBoxWithSpaces = 200;

	int lengthBox = 100;
	int startInBox = 50;

	CPaintDC dc(this);

	COLORREF borderColor(RGB(51, 204, 255)); // my COLOR

	MyShape* shape;

	int indexX = -1, indexY = -1;


	if (gameActive)
	if (IndexesOfNewShape(&indexX, &indexY, point))
	{
		if (game.ValidMove(indexX, indexY)) {

			if (game.CurrentPlayer() == SIGN_X)
			{
				shape = new MySquare(startX + startInBox + indexX * 200, startY + startInBox + indexY * 200, startX + startInBox + lengthBox + indexX * 200, startY + startInBox + lengthBox + indexY * 200, myColor);
			}
			else
			{
				shape = new MyCircle(startX + startInBox + indexX * 200, startY + startInBox + indexY * 200, startX + startInBox + lengthBox + indexX * 200, startY + startInBox + lengthBox + indexY * 200);
			}


			game.PlayMove(indexX, indexY);
			myShapes.Add(shape);

			
			// shape->Draw(dc);

			Invalidate();


			if (game.GameWin())
			{
				// Someone  WIN

				gameActive = false;

				game.ChangePlayer();

				if (game.CurrentPlayer() == SIGN_X)
				{
					scorePlayer1++;
				}
				else
				{
					scorePlayer2++;
				}

				UpdateScore( scorePlayer1,  scorePlayer2);


				MessageBox(_T(" Winner "));
			}

			if (game.IsGameEnd() && gameActive)
			{
				gameActive = false;
				MessageBox(_T(" DRAW "));
			}
		}
	}

	// initGame();

	CDialogEx::OnLButtonDown(nFlags, point);
}

void CMFCApplication10DAte2205Dlg::initGame()
{

	CPaintDC dc(this);
	CBrush cb;
	CBrush brush1; // Must initialize!

	COLORREF curColor = RGB(0, 0, 160); // RGB(0, 0, 80)


	brush1.CreateSolidBrush(RGB(220, 220, 220));

	//int startX = 400, startY = 300, end = 600;

	dc.SelectObject(&brush1);
	//dc.Rectangle(startX, startY, end + startX, end + startY);


	cb.CreateSolidBrush(RGB(255, 100, 0));
	dc.SelectObject(&cb);
	COLORREF borderColor(RGB(255, 100, 0));



	MySquare border1(startX + 390, startY, startX + 410, startY + end, borderColor); // | right
	MySquare border2(startX, startY + 190, startX + end, startY + 210, borderColor); // - top
	MySquare border3(startX + 190, startY, startX + 210, startY + end, borderColor); // | left
	MySquare border4(startX, startY + 390, startX + end, startY + 410, borderColor); // - bottom
	border1.Draw(dc); border2.Draw(dc); border3.Draw(dc); border4.Draw(dc);


	for (int i = 0; i < myShapes.GetSize(); i++)
	{
		myShapes[i]->Draw(dc);
	}

	int traingleX, trinagleY;

	if (game.CurrentPlayer() == SIGN_X)
	{
		traingleX = 300; trinagleY = 70;
		MyTriangle triangle(traingleX, trinagleY, traingleX + 50, trinagleY + 50, RGB(0, 255, 0));
		triangle.Draw(dc);
	}
	else
	{
		traingleX = 570 ; trinagleY = 70;
		MyTriangle triangle2(traingleX, trinagleY, traingleX + 50, trinagleY + 50, RGB(255, 0, 0));
		triangle2.Draw(dc);
	}
}

void CMFCApplication10DAte2205Dlg::DrawShapes()
{
	CPaintDC dc(this);
	CBrush cb;
	CBrush brush1; // Must initialize!


	brush1.CreateSolidBrush(RGB(220, 220, 220));

	//int startX = 400, startY = 300, end = 600;

	dc.SelectObject(&brush1);
	//dc.Rectangle(startX, startY, end + startX, end + startY);


	cb.CreateSolidBrush(RGB(255, 100, 0));
	dc.SelectObject(&cb);

	for (int i = 0; i < myShapes.GetSize(); i++)
	{
		myShapes[i]->Draw(dc);
	}
}


void CMFCApplication10DAte2205Dlg::DeleteMyShape()
{
	for (int i = 0; i < myShapes.GetSize(); i++)
	{
		delete myShapes[i];
	}

	myShapes.RemoveAll();
}

void CMFCApplication10DAte2205Dlg::OnBnClickedbtnrematch()
{
	game.Rematch();

	for (int i = 0; i < myShapes.GetSize(); i++)
	{
		delete myShapes[i];
	}

	myShapes.RemoveAll(); // | 0 |

	gameActive = true;

	Invalidate();


}


void CMFCApplication10DAte2205Dlg::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default

	int x, y;

	int startInBox = 50;

	if (IndexesOfNewShape(&x, &y, point))
	{

		int xPixel = startX + startInBox + x * 200, yPixel = startY + startInBox + y * 200;
		for (int i = 0; i < myShapes.GetSize(); i++)
		{
			if (myShapes[i]->x0 == xPixel && myShapes[i]->y0)
			{
				MySquare* sqr = static_cast<MySquare*> (myShapes[i]);
				if (sqr != NULL) {
					sqr->setPolyColor(myColor);
					Invalidate();
				}

				break;
			}
		}
	}


	CDialogEx::OnRButtonDown(nFlags, point);
}


void CMFCApplication10DAte2205Dlg::OnBnClickedMfccolorbutton1()
{
	myColor = m_Color.GetColor();
}


void CMFCApplication10DAte2205Dlg::OnBnClickedbtnsave() // SAVE
{
	TCHAR szFilters[] = _T("Project Files(n.ms)|n.ms|All Files (*.*)|(*.*)||");
	CFileDialog fileDlg(FALSE, _T("ms"), _T("n.ms"), OFN_HIDEREADONLY, szFilters);
	if (fileDlg.DoModal() == IDOK) {
		CFile file(fileDlg.GetPathName(), CFile::modeCreate | CFile::modeWrite);
		CArchive ar(&file, CArchive::store); // SAVE
		myShapes.Serialize(ar);
		game.Serialize(ar);
		ar.Close();
		file.Close();
	}
}


void CMFCApplication10DAte2205Dlg::OnBnClickedbtnload()
{
	TCHAR szFilters[] = _T("Project Files(n.ms)|n.ms|All Files (*.*)|(*.*)||");
	CFileDialog fileDlg(FALSE, _T("ms"), _T("n.ms"), OFN_HIDEREADONLY, szFilters);
	if (fileDlg.DoModal() == IDOK) {
		CFile file(fileDlg.GetPathName(), CFile::modeRead);
		CArchive ar(&file, CArchive::load);
		DeleteMyShape();
		myShapes.RemoveAll();
		myShapes.Serialize(ar);
		game.Serialize(ar);
		ar.Close();
		file.Close();
		Invalidate();
		scorePlayer1 = game.GetPlayer1Wins(); 
		scorePlayer2 = game.GetPlayer2Wins();
		UpdateScore(scorePlayer1, scorePlayer2);
	}
}

void CMFCApplication10DAte2205Dlg::OnBnClickedbtnbyebye()
{
	DeleteMyShape();
	CDialog::OnCancel();
}
