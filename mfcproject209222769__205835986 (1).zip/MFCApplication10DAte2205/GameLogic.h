#pragma once

#define SIGN_NONE 0
#define SIGN_X 1
#define SIGN_O 2


class GameLogic : public CObject
{
	DECLARE_SERIAL(GameLogic)
public:

	/*
	int mat[3][3] = { 0 };

	int numberOfMoves;

	int playerPlaying = SIGN_X;

	*/
	


	void Serialize(CArchive& ar)
	{
		CObject::Serialize(ar);
		if (ar.IsStoring()) // SAVE
		{
			ar << numberOfMoves;
			ar << playerPlaying;

			for (int i = 0; i < 3; i++)
			{
				for (int k = 0; k < 3; k++)
				{
					ar << mat[i][k];
				}
			}

			ar << player1Wins;
			ar << player2Wins;
		}
		else
		{
			ar >> numberOfMoves;
			ar >> playerPlaying;

			for (int i = 0; i < 3; i++)
			{
				for (int k = 0; k < 3; k++)
				{
					ar >> mat[i][k];
				}
			}

			ar >> player1Wins;
			ar >> player2Wins;
		}
	}



	GameLogic()
	{
		numberOfMoves = 9;
		player1Wins = 0;
		player2Wins = 0;
	}

	bool ValidMove(int x, int y)
	{
		if (mat[y][x] == SIGN_NONE)
		{
			return true;
		}

		return false;
	}

	void PlayMove(int x, int y)
	{
		mat[y][x] = playerPlaying;
		numberOfMoves--;

		ChangePlayer();
	}

	void ChangePlayer()
	{
		if (playerPlaying == SIGN_X) {
			playerPlaying = SIGN_O;
		}
		else
		{
			playerPlaying = SIGN_X;
		}
	}

	int CurrentPlayer()
	{
		return playerPlaying;
	}

	bool GameWin()
	{

		int index = 0;
		int x = 0;
		int y = 0;


		int prevSign = 0;

		//int x = index / 3;
		//int y = index % 3;

		bool answer = true;

		for (int i = 0; i < 8; i++)
		{
			answer = true;

			for (int k = 0; k < 3; k++)
			{
				index = optionsToWin[i][k];
				x = index / 3;
				y = index % 3;

				if (mat[x][y] == SIGN_NONE)
				{
					answer = false;
					break;
				}

				if (k > 0 && prevSign != mat[x][y])
				{
					answer = false;
					break;
				}

				prevSign = mat[x][y];

			}

			if (answer == true)
			{
				return answer;
			}
		}

		return false;

	}

	bool IsGameEnd() 
	{
		return numberOfMoves <= 0;
	}


	void Rematch() 
	{
		for (int i = 0; i < 3; i++) 
		{
			for (int k = 0; k < 3; k++) 
			{
				mat[i][k] = SIGN_NONE;
			}
		}

		numberOfMoves = 9;
		playerPlaying = SIGN_X;
	}

	void SetPlayer1Wins(int score) 
	{
		player1Wins = score;
	}

	void SetPlayer2Wins(int score)
	{
		player2Wins = score;
	}

	int GetPlayer2Wins()
	{
		return player2Wins;
	}

	int GetPlayer1Wins()
	{
		return player1Wins;
	}


private:

	int mat[3][3] = { 0 };

	int numberOfMoves;

	int playerPlaying = SIGN_X;

	int player1Wins;
	int player2Wins;


	int optionsToWin[8][3] =
	{
		{0 , 3 , 6},
		{1 , 4 , 7},
		{2 , 5 , 8},
		{0 , 4 , 8},
		{2 , 4 , 6},
		{0, 1, 2},
		{3, 4, 5},
		{6 ,7, 8}
	};
};

