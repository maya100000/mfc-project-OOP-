#include "pch.h"
#include "GameLogic.h"


IMPLEMENT_SERIAL(GameLogic, CObject, 1)
